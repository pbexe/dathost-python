from wrapper import dathost

dathost = dathost("miles@budden.net", "dathost12349876$^")

print(dathost.edit("570e1dadcde5f567e658b6f7", csgo_settings__rcon = "Bob", name = "Bob"))
